"""Bundled Workflow plugin package."""
