import"./src-DiyhtlPM.js";import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./chunk-I66GZJ75-iaOL_FXG.js";import"./chunk-NSK5VX7P-DIqcaga3.js";import"./chunk-4I5QYGJK-CDZqqvJa.js";import"./chunk-WRU74C26-BIJHUAXw.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-x5EDKzVO.js";import"./chunk-2GRJ4B5K-s_lUfkou.js";import"./chunk-XXDRQBXY-07j8Bflc.js";import"./chunk-KBJHAD2P-Otf8g_5f.js";import"./chunk-W5SLKNZC-D3ivxjwX.js";import"./chunk-QR6OTTB3-WI0Js3DP.js";import"./chunk-7Z6QIM7H-DvEGpGu8.js";import"./chunk-J7OUQ5F2-CUFQN6h1.js";import"./chunk-ZIRB5QZD-O39ZBUk3.js";import{r as t,t as n}from"./chunk-JQJVKLGR-DuYUBphj.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};